var express = require('express');
var router = express.Router();
const employModel = require('../database/model/employ')
const sequelize = require('sequelize');
const errorHandler = require('../utils/errorHandler');


/* GET users listing. */
router.get('/', async function (req, res, next) {
  try {
    const employ = await employModel.findAll()
    res(employ)
  } catch (error) {
    console.log(error);
    errorHandler(res, error);
  }
  res.send('respond with a resource');
});


router.post('/create', async function (req, res) {
  try {
    const creatEmploy = await employModel.create ({
      firstname: req.body.firstName,
      lastname:req.body.lastName,
      nationalId: req.body.nationalId,
      gender: req.body.gender,
      position: req.body.position,
      birthday: req.body.birthday
    })
    console.log(creatEmploy);
    delete company.dataValues.updatedAt
    delete company.dataValues.createdAt
    res(createEmploy)
  } catch {
    errorHandler(res , error)
  }
})

router.put('/:id' , async function(req, res) {
  try{
    const targetemploy = await employModel.findByPk(req.params.id)
    if(!targetemploy){
      res.status(404).send({message: "user not found"})
      }
      targetemploy.update(req.body)
      console.log(targetemploy);
      res.send(targetemploy)
  }catch (error){
    console.log(error);
    errorHandler(res , error)
  }
})
router.delete('/:id' , async function(req, res) {
  try{
    const targetemploy = await employModel.findByPk(req.params.id)
    if(!targetemploy){
      res.status(404).send({message: "user not found"})
      }
      targetemploy.destroy()
      console.log(targetemploy);
      res.send({message: "user deleted"})
  }catch (error){
    console.log(error);
    errorHandler(res , error)
  }
})

module.exports = router;
