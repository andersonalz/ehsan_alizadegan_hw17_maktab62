const express = require('express');
const router = express.Router();
const companyModel = require('../database/model/company');
// const { ValidationError } = require('sequelize');
const errorHandler = require('../utils/errorHandler');

// router.get('/home', async function (req, res, next) {
//   res.render('company' , {title : 'Home'})
// });
/* GET home page. */
router.get('/', async function (req, res, next) {
  try {
    const companies = await companyModel.findAll()
    return res.json(companies)
  } catch (error) {
    console.log(error)
      // console.log(error.message);
      // res.status(500).send(error.message, { message: "failed operation" })
      errorHandler(res , error)
  }
});

router.post('/create', async function (req, res) {
  try {
    const company = await companyModel.create({
      name: req.body.name,
      registrationNumber: req.body.registrationNumber,
      city: req.body.city,
      province: req.body.province,
      number: req.body.number,
      registerDate: req.body.registerDate
    })
    console.log(company);
    delete company.dataValues.updatedAt
    delete company.dataValues.createdAt
    res.send(company)
  } catch (error) {
    console.log(error);
    errorHandler(res , error)
  }
})

router.put('/:id' ,async function (req, res) {
  try {
    // console.log(req.params);
    // console.log(req.body);
    // const findOneCompany = await companyModel.findOne({
    //     where : {id : req.params.id}
    // })
    const findOneCompany = await companyModel.findByPk(req.params.id)
    // console.log(findOneCompany);
    if(!findOneCompany){
      return res.status(404).send({message : "user not found"})
    }
     await findOneCompany.update(req.body)
    // const updateCompany = await companyModel.update({
       
    // })
    // console.log(deleteCompany);
    delete findOneCompany.dataValues.updatedAt
    delete findOneCompany.dataValues.createdAt
    res.send(findOneCompany)
  } catch (error) {
    console.log(error);
    errorHandler(res , error)
  }
})

router.delete('/:id' ,async function (req, res) {
  try {
    const deleteCompany = await companyModel.findByPk(req.params.id)
    if(!deleteCompany) {
      res.status(404).send({ message : "user not found"})
    }
    await deleteCompany.destroy()
    res.send({message :"delete success"})
  } catch (error) {
    console.log(error);
    errorHandler(res , error)
  }
})
module.exports = router;
